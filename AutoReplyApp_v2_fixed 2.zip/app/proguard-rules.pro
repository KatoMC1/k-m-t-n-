# Add project specific ProGuard rules here.
-keep class com.autoreply.app.** { *; }
