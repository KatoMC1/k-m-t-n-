package com.autoreply.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.Log

class CallReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "CallReceiver"

        // Trạng thái cuộc gọi giữa các lần broadcast
        private var lastCallState = TelephonyManager.CALL_STATE_IDLE
        private var incomingNumber = ""
        private var replySentForThisCall = false  // tránh gửi 2 lần trong 1 cuộc gọi
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.intent.action.PHONE_STATE") return

        val prefs = PrefsManager(context)
        if (!prefs.isEnabled || !prefs.replyOnCall) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return

        // Android 9 trở xuống: số có trong intent luôn
        // Android 10+: số chỉ có ở lần RINGING đầu tiên nếu có READ_CALL_LOG,
        //              còn không thì phải đọc từ CallLog sau khi idle
        val numberFromIntent = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        } else {
            // Android 10+: intent vẫn trả số nếu app có READ_PHONE_STATE + READ_CALL_LOG
            // Lấy thử, fallback sang CallLog nếu rỗng
            intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        }

        Log.d(TAG, "Phone state: $state | number from intent: '$numberFromIntent'")

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                // Cuộc gọi đến — cập nhật số nếu có
                if (numberFromIntent.isNotEmpty()) {
                    incomingNumber = numberFromIntent
                }
                replySentForThisCall = false
                lastCallState = TelephonyManager.CALL_STATE_RINGING

                Log.d(TAG, "RINGING — incomingNumber='$incomingNumber'")

                // ── MODE: Gửi ngay khi có cuộc gọi đến ──
                if (prefs.replyOnRinging) {
                    if (incomingNumber.isNotEmpty()) {
                        handleIncomingCall(context, incomingNumber, prefs, trigger = "Cuộc gọi đến")
                    } else {
                        // Số chưa có (Android 10+ delay) — thử lại sau 1.5s
                        scheduleRetryWithCallLog(context, prefs, trigger = "Cuộc gọi đến")
                    }
                }
            }

            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Đã bắt máy — không gửi gì thêm
                lastCallState = TelephonyManager.CALL_STATE_OFFHOOK
            }

            TelephonyManager.EXTRA_STATE_IDLE -> {
                val prevState = lastCallState
                val savedNumber = incomingNumber

                lastCallState = TelephonyManager.CALL_STATE_IDLE
                incomingNumber = ""

                // ── MODE: Chỉ gửi khi missed call ──
                if (!prefs.replyOnRinging && prevState == TelephonyManager.CALL_STATE_RINGING) {
                    // Cuộc gọi nhỡ (RINGING → IDLE, không qua OFFHOOK)
                    if (savedNumber.isNotEmpty()) {
                        handleIncomingCall(context, savedNumber, prefs, trigger = "Cuộc gọi nhỡ")
                    } else {
                        // Android 10+: đọc số từ CallLog sau 2s (chờ hệ thống ghi log xong)
                        scheduleRetryWithCallLog(context, prefs, trigger = "Cuộc gọi nhỡ")
                    }
                }

                replySentForThisCall = false
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    // Xử lý gửi reply (check cooldown + gửi SMS + record)
    // ──────────────────────────────────────────────────────────
    private fun handleIncomingCall(
        context: Context,
        phoneNumber: String,
        prefs: PrefsManager,
        trigger: String
    ) {
        if (replySentForThisCall) {
            Log.d(TAG, "Reply already sent for this call, skip.")
            return
        }

        if (!prefs.canSendReply(phoneNumber)) {
            val remaining = prefs.getRemainingCooldownMinutes(phoneNumber)
            Log.d(TAG, "Cooldown active for $phoneNumber — $remaining phút còn lại")
            return
        }

        sendAutoReply(context, phoneNumber, prefs.replyMessage, prefs, trigger)
        replySentForThisCall = true
    }

    // ──────────────────────────────────────────────────────────
    // Fallback Android 10+: đọc CallLog sau delay ngắn
    // ──────────────────────────────────────────────────────────
    private fun scheduleRetryWithCallLog(
        context: Context,
        prefs: PrefsManager,
        trigger: String,
        delayMs: Long = 2000L
    ) {
        Log.d(TAG, "Number not in intent, scheduling CallLog retry in ${delayMs}ms...")
        val appContext = context.applicationContext
        Handler(Looper.getMainLooper()).postDelayed({
            val number = getLastIncomingNumberFromCallLog(appContext)
            if (number != null) {
                Log.d(TAG, "Got number from CallLog: $number")
                handleIncomingCall(appContext, number, prefs, trigger)
            } else {
                Log.w(TAG, "CallLog fallback: could not determine incoming number")
            }
        }, delayMs)
    }

    /**
     * Đọc số điện thoại cuộc gọi đến gần nhất từ CallLog.
     * Yêu cầu quyền READ_CALL_LOG.
     * Chỉ lấy cuộc gọi trong vòng 30 giây gần đây để tránh nhầm.
     */
    private fun getLastIncomingNumberFromCallLog(context: Context): String? {
        val cutoffTime = System.currentTimeMillis() - 30_000L
        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.DATE, CallLog.Calls.TYPE),
                "${CallLog.Calls.DATE} > ? AND ${CallLog.Calls.TYPE} IN (?, ?)",
                arrayOf(
                    cutoffTime.toString(),
                    CallLog.Calls.INCOMING_TYPE.toString(),
                    CallLog.Calls.MISSED_TYPE.toString()
                ),
                "${CallLog.Calls.DATE} DESC"
            )
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER))
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Error reading CallLog: ${e.message}")
            null
        } finally {
            cursor?.close()
        }
    }

    // ──────────────────────────────────────────────────────────
    // Gửi SMS
    // ──────────────────────────────────────────────────────────
    private fun sendAutoReply(
        context: Context,
        phoneNumber: String,
        message: String,
        prefs: PrefsManager,
        trigger: String
    ) {
        try {
            @Suppress("DEPRECATION")
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }

            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)

            prefs.recordReplySent(phoneNumber)

            Log.d(TAG, "Auto-reply sent to $phoneNumber [$trigger]")
            NotificationHelper.showReplySentNotification(context, phoneNumber, trigger)

        } catch (e: Exception) {
            Log.e(TAG, "Failed to send auto-reply to $phoneNumber: ${e.message}")
        }
    }
}
