# AutoReplyApp v2.0

Ứng dụng tự động trả lời SMS và cuộc gọi cho Android.

## Tính năng
- ✅ Tự động reply SMS khi có tin nhắn mới
- ✅ Reply khi có cuộc gọi nhỡ (missed call)
- ✅ **MỚI:** Reply ngay khi máy bắt đầu rung (không cần chờ missed)
- ✅ Cooldown per-contact (cấu hình số tiếng)
- ✅ Auto-start sau reboot
- ✅ Fix Android 10+ (CallLog fallback cho số điện thoại)
- ✅ Fix Android 14 (foregroundServiceType)

## Cách build APK

### Yêu cầu
- Android Studio Hedgehog (2023.1.1) trở lên
- JDK 17+
- Android SDK với API 34

### Các bước
1. Mở Android Studio → **File > Open** → chọn thư mục `AutoReplyApp`
2. Chờ Gradle sync xong (lần đầu tải ~2-3 phút)
3. Cắm điện thoại hoặc dùng Emulator
4. Bấm **▶ Run** (Shift+F10) → APK tự cài lên máy
5. Hoặc **Build > Build Bundle(s) / APK(s) > Build APK(s)** để lấy file APK

### APK output
```
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release-unsigned.apk
```

## Cấu trúc project
```
AutoReplyApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/autoreply/app/
│   │   │   ├── MainActivity.kt          # UI chính
│   │   │   ├── PrefsManager.kt          # Lưu settings
│   │   │   ├── SmsReceiver.kt           # Nhận & reply SMS
│   │   │   ├── CallReceiver.kt          # Nhận & reply cuộc gọi (đã fix Android 10+)
│   │   │   ├── AutoReplyService.kt      # Foreground service
│   │   │   ├── BootReceiver.kt          # Auto-start sau reboot
│   │   │   └── NotificationHelper.kt   # Hiển thị notification
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── drawable/
│   │   │   └── values/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── gradle/wrapper/
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## Quyền cần cấp khi chạy
- Receive/Read/Send SMS
- Read Phone State
- Read Call Log (bắt buộc cho Android 10+ để lấy số cuộc gọi đến)
- Post Notifications (Android 13+)
